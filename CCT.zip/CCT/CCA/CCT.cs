﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CCT
{

    public partial class CCT : Form
    {
        public CCT()
        {
            InitializeComponent();
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(238, 239, 249);
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.DefaultCellStyle.SelectionBackColor = Color.FromArgb(201, 224, 245);
            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView1.BackgroundColor = Color.White;

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(28, 87, 140);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            //Initialization & Design settings for the datagridview
        }

        bool Multl = false;
        string ML;
        
        
        DataTableCollection tableCollection;
        public void OpenButton_Click(object sender, EventArgs e)
        {
            string open = "Make sure to select a CCT Template file, otherwise the program will crash.";
            MessageBox.Show(open);
            using (OpenFileDialog openFileDialog = new OpenFileDialog() { Filter = "Excel Workbook|*.xlsx" }  )
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    TxtFilename.Text = openFileDialog.FileName;
                    using(var stream = File.Open(openFileDialog.FileName, FileMode.Open, FileAccess.Read))
                    {
                        using(IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream))
                        {
                            DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                            {
                                ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                                {
                                    UseHeaderRow = true
                                }
                            });
                            tableCollection = result.Tables;
                            cboSheet.Items.Clear();
                            foreach (DataTable table in tableCollection)
                                cboSheet.Items.Add(table.TableName);
                            
                            
                        }
                    }
                   
                }
                 //Imports Excel file and adds the data from file to a DataTableCollection               
                        }
            if (TxtFilename.Text != "")
            {
                dataGridView1.DataSource = null;
                dataGridView1.Refresh();
                
            }
            cboSheet.Items.Remove("Info - example");
            if (cboSheet.Items.Count > 0)
            {
                cboSheet.SelectedIndex = 0;
                DataTable eng = tableCollection[cboSheet.SelectedIndex];
                dataGridView2.DataSource = eng;
            


            
                if (dataGridView2.Rows[0].Cells[0] != null)
                {
                    BDC.Language2 = dataGridView1.Rows[0].Cells[0].Value.ToString();
                }
                
                if (dataGridView2.Rows[0].Cells[1] != null)
                {
                    LocalLang.SupplierName = dataGridView1.Rows[0].Cells[1].Value.ToString();
                }
                if (dataGridView2.Rows[0].Cells[2] != null)
                {
                    LocalLang.OfferDesc = dataGridView1.Rows[0].Cells[2].Value.ToString();
                }
                if (dataGridView2.Rows[0].Cells[3] != null)
                {
                    LocalLang.DiscTitle = dataGridView1.Rows[0].Cells[3].Value.ToString();
                }
                if (dataGridView2.Rows[0].Cells[4] != null)
                {
                    LocalLang.BodyText = dataGridView1.Rows[0].Cells[4].Value.ToString();
                }
                if (dataGridView2.Rows[0].Cells[5] != null)
                {
                    LocalLang.DiscCode = dataGridView1.Rows[0].Cells[5].Value.ToString();
                }
                if (dataGridView2.Rows[0].Cells[6] != null)
                {
                    LocalLang.DiscLink = dataGridView1.Rows[0].Cells[6].Value.ToString();
                }
                if (dataGridView2.Rows[0].Cells[7] != null)
                {
                    LocalLang.Terms = dataGridView1.Rows[0].Cells[7].Value.ToString();
                }
                if (dataGridView2.Rows[0].Cells[8] != null)
                {
                    LocalLang.Keywords = dataGridView1.Rows[0].Cells[8].Value.ToString();
                }
            }
        }

        public void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = tableCollection[cboSheet.SelectedItem.ToString()];
            dataGridView1.DataSource = dt;
            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            
            ML = cboSheet.SelectedItem.ToString();
            dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[0].DefaultCellStyle.Font = new Font("Arial", 9, FontStyle.Bold);
            dataGridView1.Columns[1].DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            dataGridView1.Columns[2].DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            
            dataGridView1.Columns[3].DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            dataGridView1.Columns[4].DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            dataGridView1.Columns[5].DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            dataGridView1.Columns[6].DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                row.Height = dataGridView1.ClientRectangle.Height - dataGridView1.ColumnHeadersHeight;
            }
            
            
        }
        
        

    private void dataGridView1_SizeChanged(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                row.Height = (dataGridView1.ClientRectangle.Height - dataGridView1.ColumnHeadersHeight) / dataGridView1.Rows.Count;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }
        private void MultLang_Click(object sender, EventArgs e)
        {
          if (MultLang.Checked == true)
            {
                Multl = true;
            } 
          else
            {
                Multl = false;
            }
            
        }
        private void Clear_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Refresh();
            TxtFilename.Text = "";
            cboSheet.Items.Clear();
            cboSheet.ResetText();
            MultLang.Checked = false;
            BDC.Language1 = null;
            BDC.Language2 = null;
        }
        
        private void BuildDeal_Click(object sender, EventArgs e)
        { 
            
            if (TxtFilename.Text != "" && cboSheet.SelectedItem != null)
            {
                if (dataGridView1.Rows[0].Cells[0] != null)
                {
                    BDC.Language1 = dataGridView1.Rows[0].Cells[0].Value.ToString();
                }
           
                if (dataGridView1.Rows[0].Cells[1] != null)
                {
                    English.SupplierName = dataGridView1.Rows[0].Cells[1].Value.ToString();
                }
                if (dataGridView1.Rows[0].Cells[2] != null)
                {
                    English.OfferDesc = dataGridView1.Rows[0].Cells[2].Value.ToString();
                }
                if (dataGridView1.Rows[0].Cells[3] != null)
                {
                    English.DiscTitle = dataGridView1.Rows[0].Cells[3].Value.ToString();
                }
                if (dataGridView1.Rows[0].Cells[4] != null)
                {
                    English.BodyText = dataGridView1.Rows[0].Cells[4].Value.ToString();
                }
                if (dataGridView1.Rows[0].Cells[5] != null)
                {
                    English.DiscCode = dataGridView1.Rows[0].Cells[5].Value.ToString();
                }
                if (dataGridView1.Rows[0].Cells[6] != null)
                {
                    English.DiscLink = dataGridView1.Rows[0].Cells[6].Value.ToString();
                }
                if (dataGridView1.Rows[0].Cells[7] != null)
                {
                    English.Terms = dataGridView1.Rows[0].Cells[7].Value.ToString();
                }
                if (dataGridView1.Rows[0].Cells[8] != null)
                {
                    English.Keywords = dataGridView1.Rows[0].Cells[8].Value.ToString();
                }
                

               
               
                        
                }
            LocalLang.SupplierName = "Supplier Name";
                if(BDC.SupplierName != "") { BDC.SupplierName = LocalLang.SupplierName; }
                BDC.DiscTitle = LocalLang.DiscTitle;
                BDC.BodyText = LocalLang.BodyText;
                BDC.OfferDesc = LocalLang.OfferDesc;
                BDC.DiscCode = LocalLang.DiscCode;
                BDC.DiscLink = LocalLang.DiscLink;
                BDC.Terms = LocalLang.Terms;
                BDC.Keywords = LocalLang.Keywords;
               

                if (Multl == true & BDC.Language1 != BDC.Language2)
                {
                    var BDDE = new BuildDealSE.BuildDealDE();
                    BDDE.Show();
                    
                }
                else
                {
                if (BDC.Language1 != null)
                {
                    var BD = new BuilDealSE();
                    BD.Show();
                }
                }
            }
            
        }
        
    }

       
   

