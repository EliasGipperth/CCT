﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CCT.BuildDealSE
{
    public partial class BuildDealDE : Form
    {
        public BuildDealDE()
        {
            InitializeComponent();
            if(BDC.SupplierName == "")
            {
                label1.Text = LocalLang.SupplierName;
            }
            else
            {
                label1.Text = BDC.SupplierName;
            }
            
            DEformalButton.Text = BDC.Language1;
        }

        private void OfferHead_Click(object sender, EventArgs e)
        {
            if (BDC.DiscTitle != "")
            {

                Clipboard.SetText(BDC.DiscTitle);
            }

            else
            {
                Clipboard.Clear();
            }
        }

        private void OfferDesc_Click(object sender, EventArgs e)
        {
            if (BDC.OfferDesc != "")
            {
                Clipboard.SetText(BDC.OfferDesc);
            }

            else
            {
                Clipboard.Clear();
            }

        }

        private void DiscCode_Click(object sender, EventArgs e)
        {
            if (BDC.DiscCode != "")
            {
                Clipboard.SetText(BDC.DiscCode);
            }
            else
            {
                Clipboard.Clear();
            }
        }

        private void DiscLink_Click(object sender, EventArgs e)
        {
            if (BDC.DiscLink != "")
            {
                Clipboard.SetText(BDC.DiscLink);

            }
            else
            {
                Clipboard.Clear();
            }
        }

        private void Terms_Click(object sender, EventArgs e)
        {
            if (BDC.Terms != "")
            {
                Clipboard.SetText(BDC.Terms);

            }
            else
            {
                Clipboard.Clear();
            }
        }

        private void Steps_Click(object sender, EventArgs e)
        {
            if (BDC.Keywords != "")
            {
                Clipboard.SetText(BDC.Keywords);
            }

            else
            {
                Clipboard.Clear();
            }
        }

        private void EnglishButton_Click(object sender, EventArgs e)
        {
            
            BDC.OfferDesc = LocalLang.OfferDesc;
            BDC.DiscCode = LocalLang.DiscCode;
            BDC.DiscLink = LocalLang.DiscLink;
            BDC.Terms = LocalLang.Terms;
            BDC.Keywords = LocalLang.Keywords;
            BDC.OfferHead = LocalLang.OfferHead;
            BDC.DiscTitle = LocalLang.DiscTitle;
            BDC.BodyText = LocalLang.BodyText;
        }

        private void DEInformalButton_Click(object sender, EventArgs e)
        {
            if (BDC.BodyText != "")
            {
                Clipboard.SetText(BDC.BodyText);
            }

            else
            {
                Clipboard.Clear();
            }

        }

        private void DEformalButton_Click(object sender, EventArgs e)
        {
            BDC.OfferDesc = English.OfferDesc;
            BDC.DiscCode = English.DiscCode;
            BDC.DiscLink = English.DiscLink;
            BDC.Terms = English.Terms;
            BDC.Keywords = English.Keywords;
            BDC.OfferHead = English.OfferHead;
            BDC.DiscTitle = English.DiscTitle;
            BDC.BodyText = English.BodyText;
        }
        
    }
}
