﻿namespace CCT.BuildDealSE
{
    partial class BuildDealDE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BuildDealDE));
            this.OfferHead = new System.Windows.Forms.Button();
            this.OfferDesc = new System.Windows.Forms.Button();
            this.DiscCode = new System.Windows.Forms.Button();
            this.DiscLink = new System.Windows.Forms.Button();
            this.Terms = new System.Windows.Forms.Button();
            this.Steps = new System.Windows.Forms.Button();
            this.EnglishButton = new System.Windows.Forms.Button();
            this.DEInformalButton = new System.Windows.Forms.Button();
            this.DEformalButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.SuspendLayout();
            // 
            // OfferHead
            // 
            this.OfferHead.BackColor = System.Drawing.Color.White;
            this.OfferHead.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OfferHead.Location = new System.Drawing.Point(12, 124);
            this.OfferHead.Name = "OfferHead";
            this.OfferHead.Size = new System.Drawing.Size(164, 52);
            this.OfferHead.TabIndex = 13;
            this.OfferHead.Text = "Discount Title";
            this.OfferHead.UseVisualStyleBackColor = false;
            this.OfferHead.Click += new System.EventHandler(this.OfferHead_Click);
            // 
            // OfferDesc
            // 
            this.OfferDesc.BackColor = System.Drawing.Color.White;
            this.OfferDesc.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OfferDesc.Location = new System.Drawing.Point(12, 54);
            this.OfferDesc.Name = "OfferDesc";
            this.OfferDesc.Size = new System.Drawing.Size(164, 52);
            this.OfferDesc.TabIndex = 14;
            this.OfferDesc.Text = "Offer Description";
            this.OfferDesc.UseVisualStyleBackColor = false;
            this.OfferDesc.Click += new System.EventHandler(this.OfferDesc_Click);
            // 
            // DiscCode
            // 
            this.DiscCode.BackColor = System.Drawing.Color.White;
            this.DiscCode.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiscCode.Location = new System.Drawing.Point(12, 264);
            this.DiscCode.Name = "DiscCode";
            this.DiscCode.Size = new System.Drawing.Size(164, 52);
            this.DiscCode.TabIndex = 15;
            this.DiscCode.Text = "Discount Code";
            this.DiscCode.UseVisualStyleBackColor = false;
            this.DiscCode.Click += new System.EventHandler(this.DiscCode_Click);
            // 
            // DiscLink
            // 
            this.DiscLink.BackColor = System.Drawing.Color.White;
            this.DiscLink.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiscLink.Location = new System.Drawing.Point(12, 334);
            this.DiscLink.Name = "DiscLink";
            this.DiscLink.Size = new System.Drawing.Size(164, 52);
            this.DiscLink.TabIndex = 16;
            this.DiscLink.Text = "Discount Link";
            this.DiscLink.UseVisualStyleBackColor = false;
            this.DiscLink.Click += new System.EventHandler(this.DiscLink_Click);
            // 
            // Terms
            // 
            this.Terms.BackColor = System.Drawing.Color.White;
            this.Terms.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Terms.Location = new System.Drawing.Point(12, 404);
            this.Terms.Name = "Terms";
            this.Terms.Size = new System.Drawing.Size(164, 52);
            this.Terms.TabIndex = 17;
            this.Terms.Text = "Terms";
            this.Terms.UseVisualStyleBackColor = false;
            this.Terms.Click += new System.EventHandler(this.Terms_Click);
            // 
            // Steps
            // 
            this.Steps.BackColor = System.Drawing.Color.White;
            this.Steps.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Steps.Location = new System.Drawing.Point(12, 474);
            this.Steps.Name = "Steps";
            this.Steps.Size = new System.Drawing.Size(164, 52);
            this.Steps.TabIndex = 18;
            this.Steps.Text = "Keywords";
            this.Steps.UseVisualStyleBackColor = false;
            this.Steps.Click += new System.EventHandler(this.Steps_Click);
            // 
            // EnglishButton
            // 
            this.EnglishButton.BackColor = System.Drawing.Color.White;
            this.EnglishButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnglishButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.EnglishButton.Location = new System.Drawing.Point(197, 54);
            this.EnglishButton.Name = "EnglishButton";
            this.EnglishButton.Size = new System.Drawing.Size(108, 211);
            this.EnglishButton.TabIndex = 19;
            this.EnglishButton.Text = "English";
            this.EnglishButton.UseVisualStyleBackColor = false;
            this.EnglishButton.Click += new System.EventHandler(this.EnglishButton_Click);
            // 
            // DEInformalButton
            // 
            this.DEInformalButton.BackColor = System.Drawing.Color.White;
            this.DEInformalButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DEInformalButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.DEInformalButton.Location = new System.Drawing.Point(12, 194);
            this.DEInformalButton.Name = "DEInformalButton";
            this.DEInformalButton.Size = new System.Drawing.Size(164, 52);
            this.DEInformalButton.TabIndex = 20;
            this.DEInformalButton.Text = "Body Text";
            this.DEInformalButton.UseVisualStyleBackColor = false;
            this.DEInformalButton.Click += new System.EventHandler(this.DEInformalButton_Click);
            // 
            // DEformalButton
            // 
            this.DEformalButton.BackColor = System.Drawing.Color.White;
            this.DEformalButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DEformalButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.DEformalButton.Location = new System.Drawing.Point(197, 314);
            this.DEformalButton.Name = "DEformalButton";
            this.DEformalButton.Size = new System.Drawing.Size(108, 212);
            this.DEformalButton.TabIndex = 21;
            this.DEformalButton.Text = "Norwegian";
            this.DEformalButton.UseVisualStyleBackColor = false;
            this.DEformalButton.Click += new System.EventHandler(this.DEformalButton_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(86, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 22);
            this.label1.TabIndex = 22;
            this.label1.Text = "Supplier Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(4, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(180, 151);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Portal part";
            // 
            // groupBox2
            // 
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(4, 182);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(180, 349);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "FPS part";
            // 
            // BuildDealDE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(104)))), ((int)(((byte)(176)))));
            this.ClientSize = new System.Drawing.Size(316, 534);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DEformalButton);
            this.Controls.Add(this.DEInformalButton);
            this.Controls.Add(this.EnglishButton);
            this.Controls.Add(this.Steps);
            this.Controls.Add(this.Terms);
            this.Controls.Add(this.DiscLink);
            this.Controls.Add(this.DiscCode);
            this.Controls.Add(this.OfferDesc);
            this.Controls.Add(this.OfferHead);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "BuildDealDE";
            this.Text = "CCT(Campaign Creation Tool)";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button OfferHead;
        private System.Windows.Forms.Button OfferDesc;
        private System.Windows.Forms.Button DiscCode;
        private System.Windows.Forms.Button DiscLink;
        private System.Windows.Forms.Button Terms;
        private System.Windows.Forms.Button Steps;
        public System.Windows.Forms.Button EnglishButton;
        public System.Windows.Forms.Button DEInformalButton;
        public System.Windows.Forms.Button DEformalButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}