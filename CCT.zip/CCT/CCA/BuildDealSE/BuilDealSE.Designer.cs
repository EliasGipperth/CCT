﻿namespace CCT
{
    partial class BuilDealSE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BuilDealSE));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.DiscCodeBut = new System.Windows.Forms.Button();
            this.TermsBut = new System.Windows.Forms.Button();
            this.DiscLinkBut = new System.Windows.Forms.Button();
            this.OfferDescBut = new System.Windows.Forms.Button();
            this.StepsBut = new System.Windows.Forms.Button();
            this.OfferHead = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // DiscCodeBut
            // 
            this.DiscCodeBut.BackColor = System.Drawing.Color.White;
            this.DiscCodeBut.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiscCodeBut.Location = new System.Drawing.Point(12, 263);
            this.DiscCodeBut.Name = "DiscCodeBut";
            this.DiscCodeBut.Size = new System.Drawing.Size(164, 52);
            this.DiscCodeBut.TabIndex = 1;
            this.DiscCodeBut.Text = "Discount Code";
            this.DiscCodeBut.UseVisualStyleBackColor = false;
            this.DiscCodeBut.Click += new System.EventHandler(this.DiscCodeBut_Click);
            // 
            // TermsBut
            // 
            this.TermsBut.BackColor = System.Drawing.Color.White;
            this.TermsBut.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TermsBut.Location = new System.Drawing.Point(12, 398);
            this.TermsBut.Name = "TermsBut";
            this.TermsBut.Size = new System.Drawing.Size(164, 52);
            this.TermsBut.TabIndex = 2;
            this.TermsBut.Text = "Terms";
            this.TermsBut.UseVisualStyleBackColor = false;
            this.TermsBut.Click += new System.EventHandler(this.TermsBut_Click);
            // 
            // DiscLinkBut
            // 
            this.DiscLinkBut.BackColor = System.Drawing.Color.White;
            this.DiscLinkBut.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiscLinkBut.Location = new System.Drawing.Point(12, 331);
            this.DiscLinkBut.Name = "DiscLinkBut";
            this.DiscLinkBut.Size = new System.Drawing.Size(164, 52);
            this.DiscLinkBut.TabIndex = 7;
            this.DiscLinkBut.Text = "Discount Link";
            this.DiscLinkBut.UseVisualStyleBackColor = false;
            this.DiscLinkBut.Click += new System.EventHandler(this.DiscLinkBut_Click);
            // 
            // OfferDescBut
            // 
            this.OfferDescBut.BackColor = System.Drawing.Color.White;
            this.OfferDescBut.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OfferDescBut.Location = new System.Drawing.Point(12, 54);
            this.OfferDescBut.Name = "OfferDescBut";
            this.OfferDescBut.Size = new System.Drawing.Size(167, 52);
            this.OfferDescBut.TabIndex = 8;
            this.OfferDescBut.Text = "Offer Description";
            this.OfferDescBut.UseVisualStyleBackColor = false;
            this.OfferDescBut.Click += new System.EventHandler(this.OfferDescBut_Click);
            // 
            // StepsBut
            // 
            this.StepsBut.BackColor = System.Drawing.Color.White;
            this.StepsBut.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StepsBut.Location = new System.Drawing.Point(12, 466);
            this.StepsBut.Name = "StepsBut";
            this.StepsBut.Size = new System.Drawing.Size(164, 52);
            this.StepsBut.TabIndex = 9;
            this.StepsBut.Text = "Keywords";
            this.StepsBut.UseVisualStyleBackColor = false;
            this.StepsBut.Click += new System.EventHandler(this.StepsBut_Click);
            // 
            // OfferHead
            // 
            this.OfferHead.BackColor = System.Drawing.Color.White;
            this.OfferHead.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OfferHead.Location = new System.Drawing.Point(12, 122);
            this.OfferHead.Name = "OfferHead";
            this.OfferHead.Size = new System.Drawing.Size(167, 52);
            this.OfferHead.TabIndex = 12;
            this.OfferHead.Text = "Discount Title";
            this.OfferHead.UseVisualStyleBackColor = false;
            this.OfferHead.Click += new System.EventHandler(this.OfferHead_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(22, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 22);
            this.label1.TabIndex = 13;
            this.label1.Text = "Supplier Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 194);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 52);
            this.button1.TabIndex = 14;
            this.button1.Text = "Body Text";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(4, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(183, 151);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Portal part";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(4, 180);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(183, 347);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "FPS part";
            // 
            // BuilDealSE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(104)))), ((int)(((byte)(176)))));
            this.ClientSize = new System.Drawing.Size(191, 530);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.OfferHead);
            this.Controls.Add(this.StepsBut);
            this.Controls.Add(this.OfferDescBut);
            this.Controls.Add(this.DiscLinkBut);
            this.Controls.Add(this.TermsBut);
            this.Controls.Add(this.DiscCodeBut);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "BuilDealSE";
            this.Text = "CCT";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button DiscCodeBut;
        private System.Windows.Forms.Button TermsBut;
        private System.Windows.Forms.Button DiscLinkBut;
        private System.Windows.Forms.Button OfferDescBut;
        private System.Windows.Forms.Button StepsBut;
        private System.Windows.Forms.Button OfferHead;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}