﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCT
{
    class LocalLang
    {
        public static string SupplierName { get; set; }
        public static string OfferDesc { get; set; }
        public static string DiscTitle { get; set; }
        public static string BodyText { get; set; }

        public static string DiscCode { get; set; }
        public static string DiscLink { get; set; }
        public static string Terms { get; set; }
        public static string Keywords { get; set; }
        public static string OfferHead { get; set; }
    }
}
